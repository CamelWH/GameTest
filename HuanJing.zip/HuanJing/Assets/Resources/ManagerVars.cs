﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ManagerVars : ScriptableObject
{
    public static ManagerVars GetManagerVars()
    {
        return Resources.Load<ManagerVars>("ManagerVarContainer");
    }

    public List<Sprite> bgThemeSpriteList = new List<Sprite>();

    public List<Sprite> platformThemeSpriteList = new List<Sprite>();

    public GameObject normalPlatformPre;
    public List<GameObject> commonPlatGroup = new List<GameObject>();
    public List<GameObject> grassPlatGroup = new List<GameObject>();
    public List<GameObject> winterPlatGroup = new List<GameObject>();
    public GameObject spikePlatformLeft;
    public GameObject spikePlatformRight;

    public GameObject characterPre;

    public float nextXPos = 0.55f, nextYPos = 0.645f;

}